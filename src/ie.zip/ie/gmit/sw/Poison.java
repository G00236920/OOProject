package ie.gmit.sw;

public class Poison extends Shingle {

	public Poison() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Poison(int docId, int hashcode) {
		super(docId, hashcode);
		// TODO Auto-generated constructor stub
	}

	

}
